package com.flightApp.model;

public class Flight {

}
