package com.flightApp.Repository;

public class FlightBookingRepository {

}
