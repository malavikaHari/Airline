package com.flightApp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightApp.Service.FlightbookingService;

@RestController
@RequestMapping("/api/v1.0/flight")
public class FlightBookingController {
	
	@Autowired
	private FlightbookingService flightbookingService;

}
